import tkinter as tk
from tkinter import messagebox, ttk
import json
import os
from datetime import datetime

class MovieLibrary:
    def __init__(self, root):
        self.root = root
        self.root.title("🎬 Личная кинотека")
        self.root.geometry("850x600")
        self.root.resizable(False, False)
        self.root.configure(bg="#1a1a2e")
        
        # Данные
        self.movies = []          # Список фильмов
        self.filtered_movies = [] # Отфильтрованные фильмы
        
        # Загрузка данных
        self.load_movies()
        
        # Создание интерфейса
        self.create_widgets()
        
        # Обновление таблицы
        self.refresh_table()
    
    # ========== Загрузка и сохранение данных ==========
    def load_movies(self):
        """Загружает фильмы из movies.json"""
        default_movies = [
            {"title": "Побег из Шоушенка", "genre": "Драма", "year": 1994, "rating": 9.3},
            {"title": "Крёстный отец", "genre": "Криминал", "year": 1972, "rating": 9.2},
            {"title": "Тёмный рыцарь", "genre": "Боевик", "year": 2008, "rating": 9.0},
            {"title": "Криминальное чтиво", "genre": "Криминал", "year": 1994, "rating": 8.9},
            {"title": "Властелин колец: Возвращение короля", "genre": "Фэнтези", "year": 2003, "rating": 9.0},
            {"title": "Форрест Гамп", "genre": "Драма", "year": 1994, "rating": 8.8},
            {"title": "Начало", "genre": "Фантастика", "year": 2010, "rating": 8.8},
            {"title": "Матрица", "genre": "Фантастика", "year": 1999, "rating": 8.7},
        ]
        
        try:
            with open("movies.json", "r", encoding="utf-8") as f:
                self.movies = json.load(f)
                if not self.movies:
                    self.movies = default_movies
        except (FileNotFoundError, json.JSONDecodeError):
            self.movies = default_movies
            self.save_movies()
    
    def save_movies(self):
        """Сохраняет фильмы в movies.json"""
        with open("movies.json", "w", encoding="utf-8") as f:
            json.dump(self.movies, f, ensure_ascii=False, indent=4)
    
    # ========== Создание интерфейса ==========
    def create_widgets(self):
        # Стили
        bg_color = "#1a1a2e"
        frame_bg = "#16213e"
        entry_bg = "#0f3460"
        text_color = "#e94560"
        light_text = "#eeeeee"
        
        # Заголовок
        title = tk.Label(self.root, text="🎬 Личная кинотека", 
                         font=("Arial", 20, "bold"), bg=bg_color, fg=text_color)
        title.pack(pady=10)
        
        # ========== Фрейм для добавления фильма ==========
        add_frame = tk.LabelFrame(self.root, text="➕ Добавить фильм", 
                                   bg=frame_bg, fg=light_text, font=("Arial", 11, "bold"))
        add_frame.pack(pady=10, padx=20, fill="x")
        
        # Поле: Название
        tk.Label(add_frame, text="Название:", bg=frame_bg, fg=light_text).grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.title_entry = tk.Entry(add_frame, width=25, bg=entry_bg, fg=light_text, insertbackground=light_text)
        self.title_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Поле: Жанр
        tk.Label(add_frame, text="Жанр:", bg=frame_bg, fg=light_text).grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.genre_entry = tk.Entry(add_frame, width=15, bg=entry_bg, fg=light_text, insertbackground=light_text)
        self.genre_entry.grid(row=0, column=3, padx=5, pady=5)
        
        # Поле: Год
        tk.Label(add_frame, text="Год:", bg=frame_bg, fg=light_text).grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.year_entry = tk.Entry(add_frame, width=10, bg=entry_bg, fg=light_text, insertbackground=light_text)
        self.year_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        # Поле: Рейтинг
        tk.Label(add_frame, text="Рейтинг (0-10):", bg=frame_bg, fg=light_text).grid(row=1, column=2, padx=5, pady=5, sticky="w")
        self.rating_entry = tk.Entry(add_frame, width=10, bg=entry_bg, fg=light_text, insertbackground=light_text)
        self.rating_entry.grid(row=1, column=3, padx=5, pady=5, sticky="w")
        
        # Кнопка добавления
        add_btn = tk.Button(add_frame, text="➕ Добавить фильм", command=self.add_movie,
                            bg=text_color, fg="white", font=("Arial", 10, "bold"), cursor="hand2")
        add_btn.grid(row=2, column=0, columnspan=4, pady=10)
        
        # ========== Фрейм для фильтрации ==========
        filter_frame = tk.LabelFrame(self.root, text="🔍 Фильтрация", 
                                      bg=frame_bg, fg=light_text, font=("Arial", 11, "bold"))
        filter_frame.pack(pady=10, padx=20, fill="x")
        
        # Фильтр по жанру
        tk.Label(filter_frame, text="Жанр:", bg=frame_bg, fg=light_text).grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.genre_filter = ttk.Combobox(filter_frame, values=["Все"], state="readonly", width=20)
        self.genre_filter.grid(row=0, column=1, padx=5, pady=5)
        self.genre_filter.current(0)
        
        # Фильтр по году
        tk.Label(filter_frame, text="Год:", bg=frame_bg, fg=light_text).grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.year_filter = ttk.Combobox(filter_frame, values=["Все"], state="readonly", width=15)
        self.year_filter.grid(row=0, column=3, padx=5, pady=5)
        self.year_filter.current(0)
        
        # Кнопка фильтрации
        filter_btn = tk.Button(filter_frame, text="🔍 Применить фильтр", command=self.filter_movies,
                               bg="#4CAF50", fg="white", font=("Arial", 9, "bold"), cursor="hand2")
        filter_btn.grid(row=0, column=4, padx=10, pady=5)
        
        # Кнопка сброса фильтра
        reset_btn = tk.Button(filter_frame, text="🔄 Сбросить", command=self.reset_filter,
                              bg="#f44336", fg="white", font=("Arial", 9, "bold"), cursor="hand2")
        reset_btn.grid(row=0, column=5, padx=5, pady=5)
        
        # ========== Таблица с фильмами ==========
        table_frame = tk.LabelFrame(self.root, text="📋 Список фильмов", 
                                     bg=frame_bg, fg=light_text, font=("Arial", 11, "bold"))
        table_frame.pack(pady=10, padx=20, fill="both", expand=True)
        
        # Создание Treeview (таблицы)
        columns = ("Название", "Жанр", "Год", "Рейтинг")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        
        # Настройка колонок
        self.tree.heading("Название", text="Название")
        self.tree.heading("Жанр", text="Жанр")
        self.tree.heading("Год", text="Год")
        self.tree.heading("Рейтинг", text="Рейтинг")
        
        self.tree.column("Название", width=300)
        self.tree.column("Жанр", width=120)
        self.tree.column("Год", width=80)
        self.tree.column("Рейтинг", width=80)
        
        # Полосы прокрутки
        scrollbar_y = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        scrollbar_x = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
        
        # Размещение
        self.tree.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        scrollbar_y.grid(row=0, column=1, sticky="ns", pady=5)
        scrollbar_x.grid(row=1, column=0, sticky="ew", padx=5)
        
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        
        # ========== Кнопка удаления ==========
        btn_frame = tk.Frame(self.root, bg=bg_color)
        btn_frame.pack(pady=10, fill="x")
        
        delete_btn = tk.Button(btn_frame, text="🗑 Удалить выбранный фильм", command=self.delete_movie,
                               bg="#f44336", fg="white", font=("Arial", 10, "bold"), cursor="hand2", width=25)
        delete_btn.pack(side="left", padx=20)
        
        # Счётчик фильмов
        self.count_label = tk.Label(btn_frame, text=f"📊 Всего фильмов: {len(self.movies)}", 
                                     bg=bg_color, fg=light_text, font=("Arial", 10))
        self.count_label.pack(side="right", padx=20)
        
        # Обновление списка жанров и годов для фильтров
        self.update_filter_options()
    
    def update_filter_options(self):
        """Обновляет выпадающие списки фильтров"""
        genres = sorted(set(m["genre"] for m in self.movies))
        years = sorted(set(m["year"] for m in self.movies), reverse=True)
        
        self.genre_filter["values"] = ["Все"] + genres
        self.year_filter["values"] = ["Все"] + [str(y) for y in years]
    
    # ========== Валидация ввода ==========
    def validate_input(self, title, genre, year_str, rating_str):
        """Проверяет корректность ввода"""
        if not title:
            messagebox.showwarning("Ошибка", "Введите название фильма!")
            return False
        if not genre:
            messagebox.showwarning("Ошибка", "Введите жанр фильма!")
            return False
        
        # Проверка года
        try:
            year = int(year_str)
            if year < 1888 or year > datetime.now().year + 5:
                messagebox.showwarning("Ошибка", f"Год должен быть от 1888 до {datetime.now().year + 5}!")
                return False
        except ValueError:
            messagebox.showwarning("Ошибка", "Год должен быть числом!")
            return False
        
        # Проверка рейтинга
        try:
            rating = float(rating_str)
            if rating < 0 or rating > 10:
                messagebox.showwarning("Ошибка", "Рейтинг должен быть от 0 до 10!")
                return False
        except ValueError:
            messagebox.showwarning("Ошибка", "Рейтинг должен быть числом!")
            return False
        
        return True
    
    # ========== Добавление фильма ==========
    def add_movie(self):
        """Добавляет новый фильм"""
        title = self.title_entry.get().strip()
        genre = self.genre_entry.get().strip()
        year_str = self.year_entry.get().strip()
        rating_str = self.rating_entry.get().strip()
        
        if not self.validate_input(title, genre, year_str, rating_str):
            return
        
        year = int(year_str)
        rating = float(rating_str)
        
        # Добавление
        new_movie = {"title": title, "genre": genre, "year": year, "rating": rating}
        self.movies.append(new_movie)
        self.movies.sort(key=lambda x: x["title"])  # Сортировка по названию
        self.save_movies()
        
        # Очистка полей
        self.title_entry.delete(0, tk.END)
        self.genre_entry.delete(0, tk.END)
        self.year_entry.delete(0, tk.END)
        self.rating_entry.delete(0, tk.END)
        
        # Обновление интерфейса
        self.update_filter_options()
        self.refresh_table()
        messagebox.showinfo("Успех", f"Фильм «{title}» добавлен!")
    
    # ========== Фильтрация ==========
    def filter_movies(self):
        """Фильтрует фильмы по жанру и году"""
        genre = self.genre_filter.get()
        year_str = self.year_filter.get()
        
        filtered = self.movies.copy()
        
        if genre != "Все":
            filtered = [m for m in filtered if m["genre"] == genre]
        if year_str != "Все":
            year = int(year_str)
            filtered = [m for m in filtered if m["year"] == year]
        
        self.filtered_movies = filtered
        self.refresh_table(filtered=True)
        
        count = len(filtered)
        messagebox.showinfo("Фильтрация", f"Найдено фильмов: {count}")
    
    def reset_filter(self):
        """Сбрасывает фильтр"""
        self.genre_filter.current(0)
        self.year_filter.current(0)
        self.filtered_movies = []
        self.refresh_table()
    
    # ========== Отображение таблицы ==========
    def refresh_table(self, filtered=False):
        """Обновляет отображение таблицы"""
        # Очистка таблицы
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Данные для отображения
        display_movies = self.filtered_movies if filtered and self.filtered_movies else self.movies
        
        # Заполнение таблицы
        for movie in display_movies:
            rating_display = f"{movie['rating']:.1f}"
            self.tree.insert("", tk.END, values=(movie["title"], movie["genre"], movie["year"], rating_display))
        
        # Обновление счётчика
        self.count_label.config(text=f"📊 Всего фильмов: {len(self.movies)}")
    
    # ========== Удаление фильма ==========
    def delete_movie(self):
        """Удаляет выбранный фильм"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Предупреждение", "Выберите фильм для удаления!")
            return
        
        # Получение названия выбранного фильма
        values = self.tree.item(selected[0])["values"]
        title = values[0]
        
        # Подтверждение удаления
        if messagebox.askyesno("Подтверждение", f"Удалить фильм «{title}»?"):
            # Поиск и удаление
            for i, movie in enumerate(self.movies):
                if movie["title"] == title:
                    self.movies.pop(i)
                    break
            
            self.save_movies()
            self.update_filter_options()
            self.reset_filter()  # Сброс фильтра и обновление таблицы
            messagebox.showinfo("Успех", f"Фильм «{title}» удалён!")


# ========== Запуск приложения ==========
if __name__ == "__main__":
    root = tk.Tk()
    app = MovieLibrary(root)
    root.mainloop()